
console.log("JavaScript has been loaded!");