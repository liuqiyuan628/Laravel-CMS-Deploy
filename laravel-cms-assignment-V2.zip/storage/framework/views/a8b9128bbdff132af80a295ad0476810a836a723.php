<?php $__env->startSection('content'); ?>

<section class="w3-padding">

    <h2>Edit Skill</h2>

    <form method="post" action="/console/skills/edit/<?php echo e($skill->id); ?>" novalidate class="w3-margin-bottom">

        <?php echo csrf_field(); ?>

        <div class="w3-margin-bottom">
            <label for="skill_name">skill_name:</label>
            <input type="title" name="skill_name" id="skill_name" value="<?php echo e(old('skill_name', $skill->skill_name)); ?>" required>
            
            <?php if($errors->first('skill_name')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('skill_name')); ?></span>
            <?php endif; ?>
        </div>

        <div class="w3-margin-bottom">
            <label for="skill_url">skill_url:</label>
            <input type="url" name="skill_url" id="skill_url" value="<?php echo e(old('url', $skill->skill_url)); ?>">

            <?php if($errors->first('skill_url')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('skill_url')); ?></span>
            <?php endif; ?>
        </div>

     


      

        <button type="submit" class="w3-button w3-green">Edit Skill</button>

    </form>

    <a href="/console/skills/list">Back to Skill List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/qiyuanliu/Desktop/humber/semenster2/php/assignment/laravel-CMS-portfolio/laravel-blade-cms/resources/views/skills/edit.blade.php ENDPATH**/ ?>