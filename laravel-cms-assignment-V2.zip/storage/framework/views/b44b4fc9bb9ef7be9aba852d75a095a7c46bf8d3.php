<?php $__env->startSection('content'); ?>

<section class="w3-padding">

    <h2>Edit Education</h2>

    <form method="post" action="/console/educations/edit/<?php echo e($education->id); ?>" novalidate class="w3-margin-bottom">

    <?php echo csrf_field(); ?>

<div class="w3-margin-bottom">
    <label for="college_name">college_name:</label>
    <input type="title" name="college_name" id="college_name" value="<?php echo e(old('college_name', $education->college_name)); ?>" required>
    
    <?php if($errors->first('college_name')): ?>
        <br>
        <span class="w3-text-red"><?php echo e($errors->first('college_name')); ?></span>
    <?php endif; ?>
</div>

<div class="w3-margin-bottom">
    <label for="major">Major:</label>
    <input type="url" name="major" id="major" value="<?php echo e(old('major',$education->major)); ?>">

    <?php if($errors->first('major')): ?>
        <br>
        <span class="w3-text-red"><?php echo e($errors->first('major')); ?></span>
    <?php endif; ?>
</div>

<div class="w3-margin-bottom">
    <label for="GPA">GPA:</label>
    <input type="number" name="GPA" id="GPA" step=".01" value="<?php echo e(old('GPA',$education->GPA)); ?>" required>

    <?php if($errors->first('GPA')): ?>
        <br>
        <span class="w3-text-red"><?php echo e($errors->first('GPA')); ?></span>
    <?php endif; ?>
</div>


<div class="w3-margin-bottom">
    <label for="start_year">start_year:</label>
    <input type="date" name="start_year" id="start_year" value="<?php echo e(old('start_year',$education->start_year)); ?>" required>

    <?php if($errors->first('start_year')): ?>
        <br>
        <span class="w3-text-red"><?php echo e($errors->first('start_year')); ?></span>
    <?php endif; ?>
</div>

<div class="w3-margin-bottom">
    <label for="end_year">end_year:</label>
    <input type="date" name="end_year" id="end_year" value="<?php echo e(old('end_year',$education->end_year)); ?>" required>

    <?php if($errors->first('end_year')): ?>
        <br>
        <span class="w3-text-red"><?php echo e($errors->first('end_year')); ?></span>
    <?php endif; ?>
</div>

        <button type="submit" class="w3-button w3-green">Edit Education</button>

    </form>

    <a href="/console/educations/list">Back to Education List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/qiyuanliu/Desktop/humber/semenster2/php/assignment/laravel-CMS-portfolio/laravel-blade-cms/resources/views/educations/edit.blade.php ENDPATH**/ ?>