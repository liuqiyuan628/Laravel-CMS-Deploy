<?php $__env->startSection('content'); ?>

<section class="w3-padding">

    <h2>Manage Educations</h2>

    <table class="w3-table w3-stripped w3-bordered w3-margin-bottom">
        <tr class="w3-red">
            <th>college_name</th>
            <th>major</th>
            <th>GPA</th>
            <th>start_year</th>
            <th>end_year</th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($education->college_name); ?></td>
                <td><?php echo e($education->major); ?></td>
                <td><?php echo e($education->GPA); ?></td>
                <td><?php echo e($education->start_year); ?></td>
                <td><?php echo e($education->end_year); ?></td>

                <td><a href="/console/educations/edit/<?php echo e($education->id); ?>">Edit</a></td>
                <td><a href="/console/educations/delete/<?php echo e($education->id); ?>">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <a href="/console/educations/add" class="w3-button w3-green">New Education</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/qiyuanliu/Desktop/humber/semenster2/php/assignment/laravel-CMS-portfolio/laravel-blade-cms/resources/views/educations/list.blade.php ENDPATH**/ ?>